interface PartType{
    partTypeId: number,
    position: string,
}


export type { PartType };