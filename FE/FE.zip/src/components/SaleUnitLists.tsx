import ProductTypeC from "./ProductTypeC";

function UnitLists() {
  return (
    <>
      <div className="p-2">
        <ProductTypeC />
      </div>
    </>
  );
}
export default UnitLists;
